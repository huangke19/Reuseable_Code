#!/usr/bin/python
# -*- coding: utf-8 -*-


def postdata_handler(cls, **kwargs):
    """
    根据用户上传数据获取对用models类型的数据
    """
    condition = {}

    # 获取类所有类字段，根据字段名称修改对应值
    cls_fields = cls._meta.get_all_field_names()
    for name in kwargs.keys():
        if name in cls_fields:
            value = kwargs.get(name, '')
            if value != '':
                name_type = type(cls._meta.get_field(name)).__name__
                # if name_type == 'DecimalField':
                #     value = Decimal(value)
                # if name_type == 'IntegerField':
                #     value = int(value)
                if name_type in ['CharField', 'TextField',
                                 'DateField', 'DateTimeField']:
                    value = value
                condition[name] = value
    return condition
