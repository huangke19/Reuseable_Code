#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' 时间组件 '''

from django.db import models


class TimeStampMixin(models.Model):
    create_date = models.DateTimeField(
        verbose_name=u'创建时间',
        auto_now_add=True,
        editable=True
    )

    update_date = models.DateTimeField(
        verbose_name=u'更新时间',
        auto_now=True,
    )

    class Meta:
        abstract = True


class StatusMixin(models.Model):
    """
        数据基类
    """

    is_active = models.BooleanField(
        verbose_name=u'伪删除',
        default=True
    )

    class Meta:
        abstract = True
