from django.db import models

from common.models.mixins import TimeStampMixin, StatusMixin


# Create your models here.


class Monitor(TimeStampMixin):
    ''' 全站访问统计 '''
    ip = models.GenericIPAddressField(verbose_name="访问者IP")
    # visits = models.PositiveIntegerField(verbose_name="访问量")
    user_agent = models.CharField(max_length=128, verbose_name="客户端类型")
    session_id = models.CharField(
        max_length=128, verbose_name="用户session_id", default=0)
    path = models.CharField(max_length=64, verbose_name="用户访问过的地址")

    def __str__(self):
        return self.ip

    class Meta:
        verbose_name = verbose_name_plural = "统计"
