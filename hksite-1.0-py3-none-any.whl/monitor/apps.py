from django.apps import AppConfig


class MonitorConfig(AppConfig):
    name = 'monitor'
