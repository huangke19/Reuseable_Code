from django.contrib import admin

# Register your models here.
from monitor.models import Monitor


@admin.register(Monitor)
class CounterAdmin(admin.ModelAdmin):
    list_display = ('ip', 'user_agent', 'path', 'session_id')
    pass
