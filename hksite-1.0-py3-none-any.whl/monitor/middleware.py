# def simple_middleware(get_response):
#     # One-time configuration and initialization.
#
#     def middleware(request):
#         # Code to be executed for each request before
#         # the view (and later middleware) are called.
#
#         print("这是在view之前执行")
#
#         response = get_response(request)
#
#         # Code to be executed for each request/response after
#         # the view is called.
#         print("这是在view之后执行")
#
#
#         return response
#     return middleware
import time

from monitor.models import Monitor


class SimpleMonitorMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
        # One-time configuration and initialization.

    def __call__(self, request):
        # Code to be executed for each request before
        # the view (and later middleware) are called.
        # print("这是在view之前执行")
        # time_in = time.time()

        ip = request.META.get('REMOTE_ADDR')
        user_agent = request.META.get('HTTP_USER_AGENT')
        path = request.path
        session_id = request.COOKIES.get('sessionid', 0)

        if not path.startswith('/film_admin/'):
            Monitor.objects.create(
                ip=ip,
                user_agent=user_agent,
                path=path,
                session_id=session_id)

        # print('-' * 100, 'GET')
        # for k, v in request.GET.items():
        #     print(k, v)
        #
        # print('-' * 100, 'META')
        # for k, v in request.META.items():
        #     print(k, v)
        # print('-' * 100, 'COOKIES')
        # for k, v in request.COOKIES.items():
        #     print(k, v)

        response = self.get_response(request)

        # Code to be executed for each request/response after
        # the view is called.
        # print("这是在view之后执行")
        # time_out = time.time()

        # time_costs = time_out - time_in
        # print('本次访问耗时%s' % time_costs)

        return response
