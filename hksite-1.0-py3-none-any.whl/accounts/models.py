from django.contrib.auth.models import User
from django.db import models

from common.models import StatusMixin


# Create your models here.


class UserProfile(StatusMixin):
    user = models.OneToOneField(User, on_delete=models.CASCADE, primary_key=True)
    phone = models.CharField(max_length=20, blank=True)
    job = models.CharField(max_length=32, blank=True)
