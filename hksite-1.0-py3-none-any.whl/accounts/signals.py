#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' 信号 '''

from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

from accounts.models import UserProfile


@receiver(post_save, sender=User)
def create_profile_handler(sender, instance, created, **kwargs):
    if not created:
        return
        # Create the profile object, only if it is newly created.
    profile = UserProfile(user=instance)
    profile.save()
