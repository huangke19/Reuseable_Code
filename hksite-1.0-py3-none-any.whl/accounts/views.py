from django.contrib import messages
from django.contrib.auth import authenticate, logout, login
from django.shortcuts import render, redirect

# Create your views here.
from accounts.forms import NameForm


def login_view(request):
    ''' 这是一个登录的视图函数 '''
    if request.method == 'POST':
        form = NameForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(username=username, password=password)
            if user:
                login(request, user)
                return redirect("index")
            else:
                messages.add_message(request, messages.INFO, 'Hello world.')
                return render(
                    request, 'movie/login.html', {
                        'form': form, 'message': messages
                    })
        return render(request, 'movie/login.html', {'form': form})
    else:
        form = NameForm()
    return render(request, 'movie/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect("index")
