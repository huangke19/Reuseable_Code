from django import forms


class NameForm(forms.Form):
    username = forms.CharField(
        label='Your name',
        widget=forms.TextInput,
        max_length=100,
    )
    password = forms.CharField(
        label='password',
        widget=forms.PasswordInput,
        max_length=100)


class RegisterForm(forms.Form):
    username = forms.CharField(label='Your name', max_length=100)
    password1 = forms.CharField(label='password1', max_length=100)
    password2 = forms.CharField(label='password2', max_length=100)
