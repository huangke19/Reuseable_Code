#!/usr/bin/env python
# -*- coding: utf-8 -*-


from django.db import models

from common import postdata_handler
from common.models.mixins import StatusMixin, TimeStampMixin
from movie.models.movie import Film


class FilmComment(StatusMixin, TimeStampMixin):
    # user = models.ForeignKey(User, on_delete=models.CASCADE)  # 观看用户
    film = models.ForeignKey(
        Film,
        verbose_name="电影",
        on_delete=models.DO_NOTHING,
        null=True
    )  # 观看电影
    content = models.TextField(
        max_length=200,
        verbose_name='内容',
        blank=True,
        null=True)
    nickname = models.CharField(max_length=50, verbose_name="昵称", null=True)
    email = models.EmailField(verbose_name="邮箱", blank=True, null=True)
    created_time = models.DateTimeField(auto_now=True, verbose_name='创建时间')
    active = models.BooleanField(default=True)

    def __str__(self):
        return self.nickname

    def update_obj(self, **kwargs):
        condition = postdata_handler(FilmComment, **kwargs)
        for name, value in condition:
            setattr(self, name, value)
        self.save()

    class Meta:
        verbose_name = verbose_name_plural = "评论"
