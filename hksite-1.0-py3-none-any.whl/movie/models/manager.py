#!/usr/bin/env python
# -*- coding: utf-8 -*-


from django.db import models


class PublishedManager(models.Manager):
    def get_queryset(self):
        return super(PublishedManager, self).get_queryset().filter(status='发布')


class LevelManager(models.Manager):

    def _480p(self):
        return self.get_queryset().filter(pic_level='1')

    def _720p(self):
        return self.get_queryset().filter(pic_level='2')

    def _1080p(self):
        return self.get_queryset().filter(pic_level='3')

    def _4k(self):
        return self.get_queryset().filter(pic_level='4')

    def blu_ray(self):
        return self.get_queryset().filter(pic_level='5')
