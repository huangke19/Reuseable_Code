#!/usr/bin/env python
# -*- coding: utf-8 -*-


from ckeditor.fields import RichTextField
from django.contrib.auth.models import User
from django.db import models
from django.db.models import F

from movie.models.manager import LevelManager


class Film(models.Model):
    LEVEL_CHOICES = (
        (1, '480P'),
        (2, '720P'),
        (3, '1080P'),
        (4, '4K'),
        (5, '蓝光'),
    )
    STATUS_CHOICES = (
        (1, "编辑中"),
        (3, "发布"),
    )
    RATE_LEVEL = (
        (1, '未分级'),
        (2, '普通观众'),
        (3, '父母陪伴'),
        (4, '仅限成人'),
        (5, '限制级'),
    )

    name = models.CharField(max_length=128, verbose_name="名字")
    img = models.CharField(max_length=128, verbose_name="图片")
    desc = models.CharField(max_length=256, blank=True, verbose_name="摘要")
    pic_level = models.IntegerField(choices=LEVEL_CHOICES, verbose_name="画质等级")
    slug = models.SlugField(max_length=250, allow_unicode=True)
    pv = models.IntegerField(verbose_name="浏览量", default=0)
    magnets = models.CharField(max_length=256, verbose_name="磁力链")
    status = models.IntegerField(choices=STATUS_CHOICES)
    content = RichTextField()
    rating = models.IntegerField(choices=RATE_LEVEL, default=1)

    created = models.DateTimeField(auto_now_add=True, verbose_name="创建日期")
    updated = models.DateTimeField(auto_now=True, verbose_name="修改时间")

    owner = models.ForeignKey(
        User,
        related_name="user_films",
        verbose_name='作者',
        on_delete=models.CASCADE)
    topic = models.ForeignKey(
        "Topic",
        related_name="topic_films",
        verbose_name="分类",
        on_delete=models.CASCADE)
    tags = models.ManyToManyField(
        "Tag",
        related_name="tag_films",
        verbose_name="标签")

    objects = models.Manager()
    all_films = LevelManager()

    def __str__(self):
        return self.name

    def add_pv(self):
        ''' 增加pv '''
        # todo 给用户添加一个时间，比如24小时内访问过，就不增加 pv
        return self.__class__.objects.filter(pk=self.id).update(pv=F("pv") + 1)

    @classmethod
    def get_topic_films(self, top_id):
        return self.objects.filter(topic_id=top_id).all()

    class Meta:
        verbose_name = verbose_name_plural = "电影"


class Topic(models.Model):
    name = models.CharField(max_length=128, verbose_name="分类", unique=True)

    def __str__(self):
        return self.name

    @classmethod
    def front_topics(self):
        if self.objects.count() < 10:
            return self.objects.all()
        return self.objects.all()[:10]

    class Meta:
        verbose_name = verbose_name_plural = "分类"


class Tag(models.Model):
    name = models.CharField(max_length=128, verbose_name="标签", unique=True)

    def __str__(self):
        return self.name

    @classmethod
    def front_tags(self):
        if self.objects.count() < 32:
            return self.objects.all()
        return self.objects.all()[:32]

    class Meta:
        verbose_name = verbose_name_plural = "标签"
