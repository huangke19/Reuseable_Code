import json

import markdown
from dal import autocomplete
from django.contrib.auth.models import User
from django.core.cache import cache
from django.core.paginator import Paginator, EmptyPage
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect
from django.shortcuts import render
from django.views.decorators.cache import cache_page

from movie.form import CommentForm
from movie.models.comment import FilmComment
from movie.models.movie import Tag, Topic, Film


class UserAutocomplete(autocomplete.Select2QuerySetView):
    def get_queryset(self):
        # Don't forget to filter out results depending on the visitor !
        if not self.request.user.is_authenticated:
            return User.objects.none()

        qs = User.objects.all()
        if self.q:
            qs = qs.filter(username__icontains=self.q)
        return qs


class TagAutocomplete(autocomplete.Select2QuerySetView):
    def get_queryset(self):
        # Don't forget to filter out results depending on the visitor !
        if not self.request.user.is_authenticated:
            return Tag.objects.none()

        qs = Tag.objects.all()
        if self.q:
            qs = qs.filter(name__icontains=self.q)
        return qs


class TopicAutocomplete(autocomplete.Select2QuerySetView):
    def get_queryset(self):
        # Don't forget to filter out results depending on the visitor !
        if not self.request.user.is_authenticated:
            return Topic.objects.none()

        qs = Topic.objects.all()
        if self.q:
            qs = qs.filter(name__icontains=self.q)
        return qs


# @cache_page(60 * 15)
def film_list(request, tag_id=None, topic_id=None):
    ''' 电影列表页 '''
    query_set = Film.objects.all()
    page = request.GET.get('page', 1)
    page_size = 6

    if tag_id:
        tag = Tag.objects.get(pk=tag_id)
        query_set = tag.tag_films.order_by('id').all()

    elif topic_id:
        query_set = Film.get_topic_films(topic_id).order_by('id').all()

    paginator = Paginator(query_set, page_size)
    try:
        films = paginator.page(page)
    except EmptyPage:
        films = paginator.page(paginator.num_pages)

    topics = Topic.front_topics()
    tags = Tag.front_tags()

    context = {
        'contacts': films,
        'films': films.object_list,
        'topics': topics,
        'tags': tags
    }
    return render(request, 'movie/index.html', context=context)


# @cache_page(60)
def film(request, film_id):
    ''' 详情页 '''
    film = get_object_or_404(Film, pk=film_id)

    # 1小时内不重复统计pv
    sessionid = request.COOKIES.get("sessionid")
    pv_key = "{}{}".format(request.path, sessionid)
    if not cache.get(pv_key):
        cache.set(pv_key, 'visited', 60 * 60)
        film.add_pv()

    topics = Topic.front_topics()
    tags = Tag.front_tags()
    film_tags = film.tags.all()

    form = CommentForm(request.POST)
    comments = film.filmcomment_set.filter(active=True).all()

    html = markdown.markdown(film.content, extensions=[
        'markdown.extensions.extra',
        'markdown.extensions.codehilite',
        'markdown.extensions.toc'])

    context = {
        'film': film,
        'topics': topics,
        'tags': tags,
        'film_tags': film_tags,
        'html': html,
        'comment_form': form,
        'comments': comments,
    }
    return render(request, 'movie/detail.html', context=context)


def search(request):
    ''' 电影搜索 '''
    q = request.GET.get("query")
    films = Film.objects.filter(name__icontains=q).all()
    topics = Topic.front_topics()
    tags = Tag.front_tags()
    context = {
        'films': films,
        'topics': topics,
        'tags': tags,
        'query': q
    }
    return render(request, 'movie/index.html', context=context)


def ajax_search(request):
    ''' 简单查询 '''
    query_key = request.POST.get("q", None)
    qs = Film.objects.filter(
        name__contains=query_key).values_list(
        "name", flat=True)
    data = {"names": list(qs)}
    return HttpResponse(json.dumps(data), content_type="application/json")


def comment(request):
    """
    user can comment from this view function

    :param request: nickname, email, content
    :return: a redirect function
    """
    '''  '''
    if request.method == 'POST':
        path = request.POST.get("url")
        film_id = int(path.split('/')[-1])
        film = get_object_or_404(Film, pk=film_id)

        form = CommentForm(request.POST)
        if form.is_valid():
            nickname = form.cleaned_data['nickname']
            email = form.cleaned_data['email']
            content = form.cleaned_data['content']
            newcmt = FilmComment(
                nickname=nickname,
                email=email,
                content=content)
            newcmt.film = film
            newcmt.save()
            return redirect(path)
        else:
            return redirect("index")
        # if a GET (or any other method) we'll create a blank form
    else:
        return redirect("index")
