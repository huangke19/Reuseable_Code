from django.contrib import admin
from django.urls import reverse
from django.utils.html import format_html

from HKsHome.admin import film_admin_site
from movie.form import FilmAdminForm
# 自定义操作
from movie.models.comment import FilmComment
from movie.models.movie import Film, Topic, Tag


# Register your models here.


def set_level_2_480p(modeladmin, request, queryset):
    queryset.update(pic_level='1')


def set_level_2_720p(modeladmin, request, queryset):
    queryset.update(pic_level='2')


def set_level_2_1080p(modeladmin, request, queryset):
    queryset.update(pic_level='3')


def set_level_2_4k(modeladmin, request, queryset):
    queryset.update(pic_level='4')


def set_level_2_bluray(modeladmin, request, queryset):
    queryset.update(pic_level='5')


set_level_2_480p.short_description = "将所有电影分类至480P"
set_level_2_720p.short_description = "将所有电影分类至720P"
set_level_2_1080p.short_description = "将所有电影分类至1080P"
set_level_2_4k.short_description = "将所有电影分类至4K"
set_level_2_bluray.short_description = "将所有电影分类至蓝光"


@admin.register(Film, site=film_admin_site)
class FilmAdmin(admin.ModelAdmin):
    form = FilmAdminForm

    list_display = (
        'id',
        'name',
        'topic',
        'status',
        'pic_level',
        'desc',
        'created',
        'updated',
        'show_content',
        'edit_film',
        'delete_film')
    list_editable = ('topic', 'pic_level')
    # list_editable = ('')
    list_display_links = ('name', 'show_content')
    list_filter = ('topic__name', 'pic_level')
    search_fields = ('name',)
    actions_on_bottom = True
    save_on_top = False
    filter_horizontal = ('tags',)
    # prepopulated_fields = {'slug': ('name',)}
    date_hierarchy = 'created'
    raw_id_fields = ('tags',)

    actions = [
        set_level_2_480p,
        set_level_2_720p,
        set_level_2_1080p,
        set_level_2_4k,
        set_level_2_bluray,
    ]

    fieldsets = (
        (None, {
            'fields': (('name', 'topic'),
                       ('owner', 'pic_level'),
                       ('magnets'),
                       ('slug', 'status'),
                       ('pv', 'rating'),
                       'desc',
                       )}),
        ('高级信息', {
            'classes': ('wide',),
            'fields': ('tags', 'img', 'content',),
        }),
    )

    def show_content(self, obj):
        return format_html(obj.content[:40])

    def edit_film(self, obj):
        return format_html(
            '<a href="{}">编辑</a>',
            reverse('film_admin:movie_film_change', args=(obj.id,))
        )

    def delete_film(self, obj):
        return format_html(
            '<a href="{}">删除</a>',
            reverse('film_admin:movie_film_delete', args=(obj.id,))
        )

    show_content.short_description = '简介'
    delete_film.short_description = '删除'
    edit_film.short_description = '操作'

    def save_model(self, request, obj, form, change):
        obj.owner = request.user
        super(FilmAdmin, self).save_model(request, obj, form, change)


class FilmInlineAdmin(admin.StackedInline):
    fields = ('name', 'desc', 'status')
    model = Film
    extra = 1


@admin.register(Topic, site=film_admin_site)
class TopicAdmin(admin.ModelAdmin):
    list_display = ('name',)
    inlines = [
        FilmInlineAdmin,
    ]
    pass


@admin.register(Tag, site=film_admin_site)
class TagAdmin(admin.ModelAdmin):
    list_display = ('name',)
    pass


@admin.register(FilmComment, site=film_admin_site)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('film', 'nickname', 'email', 'content', 'active')
    pass
