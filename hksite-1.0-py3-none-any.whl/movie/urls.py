from django.urls import path

from movie.views import UserAutocomplete, TagAutocomplete, TopicAutocomplete
from . import views

urlpatterns = [
    # path('', FilmListView.as_view(), name='index'),
    # path('tag/<int:tag_id>', TagView.as_view(), name='tag'),
    # path('topic/<int:topic_id>', TopicView.as_view(), name='topic'),

    path(
        'user-autocomplete/',
        UserAutocomplete.as_view(),
        name='user-autocomplete'),
    path(
        'tags-autocomplete/',
        TagAutocomplete.as_view(),
        name='tags-autocomplete'),
    path(
        'topic-autocomplete/',
        TopicAutocomplete.as_view(),
        name='topic-autocomplete'),
    path('', views.film_list, name='movie_index'),
    path('tag/<int:tag_id>', views.film_list, name='tag'),
    path('topic/<int:topic_id>', views.film_list, name='topic'),
    path('film/<int:film_id>', views.film, name='film'),
    path('search/', views.search, name='movie_search'),
    path('ajax_search/', views.ajax_search, name='ajax_search'),
    path('comment', views.comment, name='movie_comment'),
]
