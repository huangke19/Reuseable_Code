from django.test import TestCase

# Create your tests here.


from common import *


print(postdata_handler.__doc__)
print(postdata_handler.__name__)
print(postdata_handler.__class__)
