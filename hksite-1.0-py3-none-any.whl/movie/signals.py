#!/usr/bin/env python
# -*- coding: utf-8 -*-


from django.db.models.signals import post_save
from django.dispatch import receiver

from movie.models.comment import FilmComment


@receiver(post_save, sender=FilmComment)
def my_callback(sender, **kwargs):
    print("有新的留言，注意查收")
    # todo 使用邮件通知站长
    return
