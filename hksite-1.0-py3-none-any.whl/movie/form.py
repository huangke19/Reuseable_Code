from dal import autocomplete
from django import forms
from django.contrib.auth.models import User

from movie.models.comment import FilmComment
from movie.models.movie import Topic, Tag


class FilmAdminForm(forms.ModelForm):
    status = forms.BooleanField(label="是否发布", required=False)
    desc = forms.CharField(widget=forms.Textarea, label="摘要", required=False)
    owner = forms.ModelChoiceField(
        queryset=User.objects.all(),
        widget=autocomplete.ModelSelect2(url='user-autocomplete')
    )
    tags = forms.ModelMultipleChoiceField(
        queryset=Tag.objects.all(),
        widget=autocomplete.ModelSelect2Multiple(url='tags-autocomplete')
    )
    topic = forms.ModelChoiceField(
        queryset=Topic.objects.all(),
        widget=autocomplete.ModelSelect2(url='topic-autocomplete')
    )

    def clean_status(self):
        if self.cleaned_data['status']:
            return 3
        else:
            return 1


from django import forms


class CommentForm(forms.ModelForm):
    class Meta:
        model = FilmComment
        fields = ['nickname', 'email', 'content']
