#!/usr/bin/env python
# -*- coding: utf-8 -*-

from django.contrib.admin import AdminSite


class BlogAdmin(AdminSite):
    site_header = '博客管理后台'
    site_title = 'TopFilm管理后台'
    index_title = 'Python，Django'


class FilmAdmin(AdminSite):
    site_header = '电影管理后台'
    site_title = 'TopFilm管理后台'
    index_title = '电影、分类、标签'


film_admin_site = FilmAdmin(name='film_admin')
blog_admin_site = BlogAdmin(name='blog_admin')
