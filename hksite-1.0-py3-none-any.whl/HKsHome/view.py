#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' 首页 '''
from django.shortcuts import render


def index(request):
    return render(request, 'index.html', locals())
