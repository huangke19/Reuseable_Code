from .base import *

DEBUG = True

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'demo.sqlite3'),
        'TEST': {
            'NAME': 'test_demo.sqlite3',
            'CHARSET': 'utf8mb4',
        },
    }
}

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'hkf=%x!7*-ej(mi5sy4m6n+mi206kkh1&q4)y=@rwhu^6)-+&c'