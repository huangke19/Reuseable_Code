#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' 标签模型 '''

from django.contrib.auth.models import User
from django.db import models

# Create your models here.
from common.models import TimeStampMixin


class Tag(TimeStampMixin):
    STATUS_NORMAL = 1
    STATUS_DELETE = 2
    STATUS_ITEMS = (
        (STATUS_NORMAL, '正常'),
        (STATUS_DELETE, '删除'),
    )
    name = models.CharField(max_length=10, verbose_name="名称")
    status = models.PositiveIntegerField(default=STATUS_NORMAL, choices=STATUS_ITEMS, verbose_name="状态")
    owner = models.ForeignKey(User, verbose_name="作者", on_delete=models.DO_NOTHING)

    class Meta:
        verbose_name = verbose_name_plural = "标签"
        ordering = ['-id']

    def __str__(self):
        return self.name


class Topic(TimeStampMixin):
    STATUS_NORMAL = 1
    STATUS_DELETE = 2
    STATUS_ITEMS = (
        (STATUS_NORMAL, '正常'),
        (STATUS_DELETE, '删除'),
    )
    name = models.CharField(max_length=10, verbose_name="专题")
    status = models.PositiveIntegerField(default=STATUS_NORMAL, choices=STATUS_ITEMS, verbose_name="状态")
    owner = models.ForeignKey(User, verbose_name="作者", on_delete=models.DO_NOTHING)

    class Meta:
        verbose_name = verbose_name_plural = "专题"
        ordering = ['-id']

    def __str__(self):
        return self.name
