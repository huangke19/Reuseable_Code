#!/usr/bin/env python
# -*- coding: utf-8 -*-

''' 分类模型 '''

from django.contrib.auth.models import User
from django.db import models

from common.models import TimeStampMixin


class Category(TimeStampMixin):
    STATUS_NORMAL = 1
    STATUS_DELETE = 2
    STATUS_ITEMS = (
        (STATUS_NORMAL, '正常'),
        (STATUS_DELETE, '删除'),
    )
    name = models.CharField(max_length=50, verbose_name="名称")
    status = models.PositiveIntegerField(default=STATUS_NORMAL)
    is_nav = models.BooleanField(default=False, verbose_name='是否为导航')
    owner = models.ForeignKey(User, verbose_name="作者", on_delete=models.DO_NOTHING)

    class Meta:
        verbose_name = verbose_name_plural = "分类"

    @classmethod
    def get_navs(cls):
        categories = cls.objects.filter(status=cls.STATUS_NORMAL)
        nav_categories, normal_categories = [], []
        for cate in categories:
            if cate.is_nav:
                nav_categories.append(cate)
            else:
                normal_categories.append(cate)

        return {
            'navs': nav_categories,
            'cates': normal_categories
        }

    def __str__(self):
        return self.name
