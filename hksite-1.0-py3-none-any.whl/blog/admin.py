#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Register your models here.
from django.contrib import admin
from django.contrib.admin.models import LogEntry
from django.urls import reverse
from django.utils.html import format_html

from HKsHome.admin import blog_admin_site
from blog.models.comment import Comment
from blog.models.config import SideBar
from blog.models.tag import Topic
from .models import Post, Category, Tag


@admin.register(Category, site=blog_admin_site)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'status', 'is_nav', 'post_count', 'create_date')

    # fields = ('name', 'status', 'is_nav')

    def save_model(self, request, obj, form, change):
        obj.owner = request.user
        return super(CategoryAdmin, self).save_model(request, obj, form, change)

    def post_count(self, obj):
        return obj.post_set.count()

    post_count.short_description = '文章数量'


@admin.register(SideBar, site=blog_admin_site)
class SideBarAdmin(admin.ModelAdmin):
    list_display = ('title', 'status')

    def save_model(self, request, obj, form, change):
        obj.owner = request.user
        return super(SideBarAdmin, self).save_model(request, obj, form, change)


@admin.register(Tag, site=blog_admin_site)
class TagAdmin(admin.ModelAdmin):
    list_display = ('name', 'status')

    def save_model(self, request, obj, form, change):
        obj.owner = request.user
        return super(TagAdmin, self).save_model(request, obj, form, change)


@admin.register(Topic, site=blog_admin_site)
class TopicAdmin(admin.ModelAdmin):
    list_display = ('name', 'status')

    def save_model(self, request, obj, form, change):
        obj.owner = request.user
        return super(TopicAdmin, self).save_model(request, obj, form, change)


@admin.register(Post, site=blog_admin_site)
class PostAdmin(admin.ModelAdmin):
    list_display = ('title', 'category', 'topic', 'status', 'operator', 'owner', 'pv', 'uv', 'create_date')
    list_display_links = ['title', ]
    list_editable = ['category', 'topic', 'owner']

    list_filter = ['category', ]
    search_fields = ['title', 'category__name']

    actions_on_top = True
    actions_on_bottom = True

    save_on_top = True

    fields = (
        ('category', 'title'),
        'desc',
        'is_md',
        'topic',
        'status',
        'tags',
        'content',
        'create_date'
    )

    def operator(self, obj):
        return format_html(
            '<a href="{}">编辑</a>',
            reverse('blog_admin:blog_post_change', args=(obj.id,))
        )

    operator.short_description = '操作'

    def save_model(self, request, obj, form, change):
        obj.owner = request.user
        return super(PostAdmin, self).save_model(request, obj, form, change)


@admin.register(LogEntry, site=blog_admin_site)
class LogEntryAdmin(admin.ModelAdmin):
    list_display = ['object_repr', 'object_id', 'action_flag', 'user', 'change_message']


@admin.register(Comment, site=blog_admin_site)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('target', 'nickname', 'content', 'website')
    list_display_links = ('nickname',)
