from django.test import TestCase

# Create your tests here.

from unittest import TestCase


class Test_Nothing(TestCase):

    def setUp(self) -> None:
        pass

    def test_unify_order(self):
        print('execute first test')
        print("success test pass ")
