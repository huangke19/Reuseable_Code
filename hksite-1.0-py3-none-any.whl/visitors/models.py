# Create your models here.

from django.contrib.auth.models import AbstractUser
from django.db import models

from common.models import StatusMixin


class Visitor(StatusMixin):
    ''' 访客 '''
    username = models.CharField(max_length=32, null=True)
    password = models.CharField(max_length=128, null=True)
    phone = models.CharField(max_length=20, blank=True)
    job = models.CharField(max_length=32, blank=True)
